
  

  function myFunction() {
   console.log("")
    var result = str.link("https://www.w3schools.com");
    document.getElementById("demo").innerHTML = result;
}
  function retrieveData(){
  	 
 
}


