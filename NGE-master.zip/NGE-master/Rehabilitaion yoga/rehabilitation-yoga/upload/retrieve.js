function writeUserData(userId, name, email, imageUrl) {
  firebase.database().ref('users/' + // put some crap inside).set({
  
  });
}

var starCountRef = firebase.database().ref('posts/' + postId + '/starCount');
starCountRef.on('value', function(snapshot) {
  updateStarCount(postElement, snapshot.val());
});


